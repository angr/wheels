from .avatar2_installer import Avatar2Installer

if __name__ == '__main__':
       Avatar2Installer().run()

