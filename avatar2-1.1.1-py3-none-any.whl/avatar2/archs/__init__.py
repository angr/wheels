from .x86 import *
from .arm import *
from .architecture import *
